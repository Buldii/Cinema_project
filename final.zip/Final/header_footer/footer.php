<?php
echo "
<footer class='footer'>
      <a href='../repertuar/repertuar.php' target='_blank' class='footer__link'>Repertuar</a>
      <a href='../Kino_kodzik/cennik.php' target='_blank' class='footer__link'>Cennik</a>
      <a href='../Kino_kodzik/regulamin.php' target='_blank' class='footer__link'>Regulamin</a>
      <a href='../Kino_kodzik/polityka_prywatnosci.php' target='_blank' class='footer__link'>Polityka prywatności</a>
      <a href='../Kino_kodzik/zwrot_biletu.php' target='_blank' class='footer__link'>Zwrot biletu</a>
      <p class='kontakt footer__link'>Kontakt: 44 715 95 60</p>
</footer>
"
?>